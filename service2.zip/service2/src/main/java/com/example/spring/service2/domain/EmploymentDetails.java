package com.example.spring.service2.domain;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmploymentDetails {
	
	List<OrgDetails> prevOrgDetails;

	public List<OrgDetails> getPrevOrgDetails() {
		return prevOrgDetails;
	}

	public void setPrevOrgDetails(List<OrgDetails> prevOrgDetails) {
		this.prevOrgDetails = prevOrgDetails;
	}

	
	@Override
	public String toString() {
		String student = null;
		try {
			student = new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return student;
	}

}
