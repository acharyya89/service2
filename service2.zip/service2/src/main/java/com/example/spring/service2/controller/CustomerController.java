package com.example.spring.service2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring.service2.domain.EmploymentDetails;
import com.example.spring.service2.domain.OrgDetails;
import com.example.spring.service2.domain.PersonalInfoDetails;

@RestController
@RequestMapping(value = "customerservice2")
public class CustomerController {

	
//	@PostMapping(value = "/test1")
//	public String getAllCustomer(@RequestBody String input) throws Exception{
//		return input;
//	}
	
	@GetMapping(value = "/test1")
	public EmploymentDetails test_1() throws Exception{
		EmploymentDetails employmentDetails = new EmploymentDetails();
		List<OrgDetails> prevOrgDetails = new ArrayList<>();
		OrgDetails orgDetails1 = new OrgDetails();
		orgDetails1.setOrgEmpId("1234");
		orgDetails1.setOrgName("Wipro");
		orgDetails1.setPfAmount(2500);
		OrgDetails orgDetails2 = new OrgDetails();
		orgDetails2.setOrgEmpId("5678");
		orgDetails2.setOrgName("Cognizant");
		orgDetails2.setPfAmount(2500);
		prevOrgDetails.add(orgDetails1);
		prevOrgDetails.add(orgDetails2);
		employmentDetails.setPrevOrgDetails(prevOrgDetails);
		return employmentDetails;
	}
	
	@GetMapping(value = "/test2")
	public PersonalInfoDetails test_2() throws Exception{
		PersonalInfoDetails personalInfoDetails = new PersonalInfoDetails();
		personalInfoDetails.setAddress("Swami Vivekananda Road.");
		personalInfoDetails.setCity("Howrah");
		personalInfoDetails.setCountry("India");
		return personalInfoDetails;
	}
	
	@GetMapping(value = "/calculateTrustScore/wipro")
	public String calculateTrustScoreWipro() throws Exception{
		return "77";
	}
	
	@GetMapping(value = "/calculateTrustScore/cognizant")
	public String calculateTrustScoreCognizant() throws Exception{
		return "88";
	}
	
}
